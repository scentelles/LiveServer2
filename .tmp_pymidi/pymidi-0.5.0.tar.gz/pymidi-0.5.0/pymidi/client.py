from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import logging
import random
import socket

from pymidi import packets
from pymidi import utils

DEFAULT_BIND_ADDR = ('0.0.0.0', 0)

class Client(object):
    STATE_INIT = 'init'
    STATE_SYNC = 'sync'
    STATE_CONNECTED = 'connected'

    def __init__(self, addr, bind_addr=DEFAULT_BIND_ADDR, ssrc=None):
        self.addr = addr
        self.bind_addr = bind_addr
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.bind(bind_addr)
        self.logger = logging.getLogger('pymidi.client')
        self.state = self.STATE_INIT

        self.ssrc = ssrc if ssrc is not None else random.randrange(2**32 - 1)
        self.sequence_number = 0

    def _build_header(self):
        timestamp = 0
        sequence_number = self.sequence_number
        self.sequence_number += 1

        return {
            'rtp_header': {
                'flags': {
                    'v': 2,
                    'p': 0,
                    'x': 0,
                    'cc': 0,
                    'm': 1,
                    'pt': 0x61,
                },
                'sequence_number': sequence_number,
            },
            'timestamp': timestamp,
            'ssrc': self.ssrc,
        }

    def send_packet(self, data):
        self.logger.debug('Sending packet: {}'.format(data))
        return data

    def send_midi_command(self, command):
        header = packets.MIDIPacketHeader.build(self._build_header())
        journal = b''
        packet = header + command + journal
        return self.send_packet(packet)

    def send_note_on(self, key, velocity=127, channel=0):
        command = packets.COMMAND_NOTE_ON | channel
        data = b'\x43' + command.to_bytes(1, 'big') + key.to_bytes(1, 'big') + velocity.to_bytes(1, 'big')
        return self.send_midi_command(data)
        # return packets.MIDIPacket.build({
        #     'header': self._build_header(),
        #     'command': {
        #         'flags': {
        #             'b': 0,
        #             'j': 0,
        #             'z': 0,
        #             'p': 0,
        #             'len': 20,
        #         },
        #         'midi_list': [
        #             {
        #                 'delta_time': 0x0,
        #                 'command_byte': 0x0,
        #                 'command': packets.COMMAND_NOTE_ON,
        #                 'channel': channel,
        #                 'params': {
        #                     'note_on': {
        #                         'key': key,
        #                         'velocity': velocity,
        #                     },
        #                 },
        #             },
        #         ],
        #     },
        #     'journal': 0x0,
        # })

c = Client(('localhost', 5001))
print(repr(c.send_note_on(0)))
